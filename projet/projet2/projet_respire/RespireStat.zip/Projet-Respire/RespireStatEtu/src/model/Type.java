package model;

public enum Type {
	SECONDAIRE, PRIMAIRE
}
